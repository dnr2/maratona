// Paste me into the FileEdit configuration dialog

#include <string>
#include <vector>
using namespace std;

class $CLASSNAME$ {
public:
   $RC$ $METHODNAME$( $METHODPARMS$ ) {

   }
};

$BEGINCUT$
$TESTCODE$

$DEFAULTMAIN$
$ENDCUT$
