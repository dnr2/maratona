// Paste me into the FileEdit configuration dialog

#include <cmath>
#include <ctime>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

class $CLASSNAME$ {
public:
   $RC$ $METHODNAME$( $METHODPARMS$ ) {

   }
};

$BEGINCUT$
$TESTCODE$ 

$DEFAULTMAIN$
$ENDCUT$
